#include <string.h>
#include <string>
#include <iostream>
using namespace std;

int main(int argc, char* argv[])
{

  return 0;
}




